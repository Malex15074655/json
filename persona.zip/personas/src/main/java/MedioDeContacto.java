
class MedioDeContacto {

    MedioDeContacto(String laboral, String string, String string0, String laboral1examplecom) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
   public class MediosDeContacto {
    public String tipo; // laboral o personal
    public String telefonoLada;
    public String telefono;
    public String correo;

    public MediosDeContacto(String tipo, String telefonoLada, String telefono, String correo) {
        this.tipo = tipo;
        this.telefonoLada = telefonoLada;
        this.telefono = telefono;
        this.correo = correo;
    }

    public String getTipo() {
        return tipo;
    }

    public String getTelefonoLada() {
        return telefonoLada;
    }

    public String getTelefono() {
        return telefono;
    }

    public String getCorreo() {
        return correo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public void setTelefonoLada(String telefonoLada) {
        this.telefonoLada = telefonoLada;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }
    
    
   }
}

 

